<script>

var init = { 
     'questions': [ 
        
		 {
           'question': 'new question',
           'answers': ['a','b','c','d'],
			  'correctAnswer': 2
       }
		
		     ],
	  'resultComments' :  
	  {
		     perfect: 'Albus, is that you?',
			 excellent: 'Outstanding, noble sir!',
			 good: 'Exceeds expectations!',
			 average: 'Acceptable. For a muggle.',
			 bad: 'Well, that was poor.',
			 poor: 'Dreadful!',
			 worst: 'For shame, troll!'
	  }

 };
 </script>