 $('#quiz-container').jquizzy({
			questions: init.questions, 
			resultComments: init.resultComments
		});