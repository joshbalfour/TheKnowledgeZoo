<script>

var init = { 
     'questions': [ 
        
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 4
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 3
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 2
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 1
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 2
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 2
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 2
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 2
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 2
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer 1','answer 2','answer 3','answer 4'],
			  'correctAnswer': 2
       },
		
		
		 {
           'question': 'question 11',
           'answers': ['a','b','c','d'],
			  'correctAnswer': 4
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer1','answer2','answer3','answer4correct'],
			  'correctAnswer': 4
       },
		
		
		 {
           'question': 'question',
           'answers': ['answ','ans','ans','ans'],
			  'correctAnswer': 4
       },
		
		
		 {
           'question': 'question',
           'answers': ['answer1','answer12','answer2','answer3'],
			  'correctAnswer': 4
       },
		
		
		 {
           'question': 'q',
           'answers': ['a','b','c','d'],
			  'correctAnswer': 2
       },
		
		
		 {
           'question': 'question 16',
           'answers': ['wrong','wrong','right','wrong'],
			  'correctAnswer': 3
       },
		
		
		 {
           'question': 'is manson straight',
           'answers': ['yes','yes','no','yes'],
			  'correctAnswer': 3
       }
		
		     ],
	  'resultComments' :  
	  {
		     perfect: 'Albus, is that you?',
			 excellent: 'Outstanding, noble sir!',
			 good: 'Exceeds expectations!',
			 average: 'Acceptable. For a muggle.',
			 bad: 'Well, that was poor.',
			 poor: 'Dreadful!',
			 worst: 'For shame, troll!'
	  }

 };
 </script>